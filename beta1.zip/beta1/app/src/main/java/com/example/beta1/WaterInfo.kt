package com.example.beta1

data class WaterInfo(
    var id: Int = 0,
    var title: String
)